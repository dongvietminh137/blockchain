# flask_server/app.py - CẬP NHẬT
from flask import Flask, request, jsonify, send_from_directory, redirect, url_for
from web3 import Web3
import json, os, time

app = Flask(__name__, static_folder='../frontend', static_url_path='')

# Cấu hình – giả định sử dụng URL RPC mặc định của Ganache
GANACHE_URL = os.environ.get('GANACHE_URL', 'http://127.0.0.1:7545')
DEPLOY_INFO = os.path.join(os.path.dirname(__file__), 'deployed.json')

w3 = Web3(Web3.HTTPProvider(GANACHE_URL))
if not w3.is_connected():
    raise RuntimeError(f"Cannot connect to Ganache at {GANACHE_URL}. Start Ganache and try again.")

# Đọc ABI và địa chỉ hợp đồng.
if not os.path.exists(DEPLOY_INFO):
    raise RuntimeError('deployed.json not found. Run deploy.py to compile & deploy the contract first.')

with open(DEPLOY_INFO) as f:
    deployed = json.load(f)

abi = deployed.get('abi')
contract_address = deployed.get('address')
if not abi or not contract_address:
    raise RuntimeError('deployed.json is missing abi or address.')

contract = w3.eth.contract(address=contract_address, abi=abi)

# Lấy tài khoản mặc định (tài khoản Ganache đầu tiên) - sẽ dùng làm 'admin/owner'
accounts = w3.eth.accounts
if not accounts:
    raise RuntimeError('No accounts found on Ganache. Make sure Ganache is running.')
DEFAULT_ACCOUNT = accounts[0]
w3.eth.default_account = DEFAULT_ACCOUNT

# Lấy địa chỉ chủ sở hữu từ hợp đồng
try:
    CONTRACT_OWNER = contract.functions.owner().call()
except Exception:
    CONTRACT_OWNER = DEFAULT_ACCOUNT # Dùng mặc định nếu lỗi gọi (chưa deploy)
    
# Cơ chế "Đăng nhập" đơn giản: Chỉ cho phép owner thực hiện các hành động C/U/D
# Trong ứng dụng thực tế, đây sẽ là phiên (session) hoặc JWT.
def is_owner(address):
    # Trong demo này, ta mặc định mọi giao dịch đều dùng DEFAULT_ACCOUNT (owner)
    # Nếu muốn thêm tính năng đăng nhập, cần quản lý nhiều ví/private keys.
    # Với thiết lập Ganache đơn giản này, ta chỉ kiểm tra xem giao dịch có phải từ Owner không.
    return address == CONTRACT_OWNER

@app.route('/')
def index():
    # Thêm biến 'owner_address' để Frontend biết ai là admin
    return send_from_directory('../frontend', 'index.html')


@app.route('/api/set-grade', methods=['POST'])
def set_grade():
    # Kiểm tra xác thực (đảm bảo chỉ owner/admin mới được thêm)
    if not is_owner(w3.eth.default_account):
        return jsonify({'status': 'error', 'message': 'Permission denied: Only contract owner can set grades.'}), 403

    data = request.get_json()
    studentId = data.get('studentId')
    course = data.get('course')
    grade = int(data.get('grade', 0))
    remark = data.get('remark', '')

    tx_hash = contract.functions.setGrade(studentId, course, grade, remark).transact({'from': w3.eth.default_account})
    receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
    return jsonify({'status': 'success', 'tx_hash': tx_hash.hex(), 'blockNumber': receipt.blockNumber})


@app.route('/api/get-grades/<student_id>', methods=['GET'])
def get_grades(student_id):
    grades = contract.functions.getGrades(student_id).call()
    result = []
    # Thêm 'index' cho frontend để biết vị trí của GradeEntry trong mảng
    for i, g in enumerate(grades):
        result.append({
            'index': i, # Vị trí trong mảng
            'timestamp': g[0],
            'course': g[1],
            'grade': g[2],
            'setter': g[3],
            'remark': g[4]
        })
    return jsonify(result)

# Endpoint Xóa điểm
@app.route('/api/delete-grade', methods=['POST'])
def delete_grade():
    # Kiểm tra xác thực
    if not is_owner(w3.eth.default_account):
        return jsonify({'status': 'error', 'message': 'Permission denied: Only contract owner can delete grades.'}), 403

    data = request.get_json()
    studentId = data.get('studentId')
    index = data.get('index') # Vị trí của mục điểm cần xóa

    if studentId is None or index is None:
        return jsonify({'status': 'error', 'message': 'Missing studentId or index.'}), 400

    try:
        tx_hash = contract.functions.deleteGrade(studentId, int(index)).transact({'from': w3.eth.default_account})
        receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
        return jsonify({'status': 'success', 'tx_hash': tx_hash.hex(), 'blockNumber': receipt.blockNumber})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

# Endpoint Sửa điểm
@app.route('/api/update-grade', methods=['POST'])
def update_grade():
    # Kiểm tra xác thực
    if not is_owner(w3.eth.default_account):
        return jsonify({'status': 'error', 'message': 'Permission denied: Only contract owner can update grades.'}), 403

    data = request.get_json()
    studentId = data.get('studentId')
    index = data.get('index')
    course = data.get('course')
    grade = int(data.get('grade', 0))
    remark = data.get('remark', '')

    if studentId is None or index is None:
        return jsonify({'status': 'error', 'message': 'Missing studentId or index.'}), 400

    try:
        tx_hash = contract.functions.updateGrade(studentId, int(index), course, grade, remark).transact({'from': w3.eth.default_account})
        receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
        return jsonify({'status': 'success', 'tx_hash': tx_hash.hex(), 'blockNumber': receipt.blockNumber})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500


# Endpoint đơn giản để lấy thông tin 'owner' cho frontend
@app.route('/api/auth/owner', methods=['GET'])
def get_owner_address():
    return jsonify({'owner': CONTRACT_OWNER})

if __name__ == '__main__':
    print(f"Contract Owner: {CONTRACT_OWNER}")
    print(f"Default Account (Admin): {DEFAULT_ACCOUNT}")
    app.run(host='0.0.0.0', port=5000, debug=True)