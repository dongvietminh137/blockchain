
import json, os
from solcx import compile_standard, install_solc
from web3 import Web3

GANACHE_URL = os.environ.get('GANACHE_URL', 'http://127.0.0.1:7545')

w3 = Web3(Web3.HTTPProvider(GANACHE_URL))
if not w3.is_connected():
    raise RuntimeError(f'Cannot connect to Ganache at {GANACHE_URL}. Start Ganache and try again.')

# Đọc file StudentManager.sol
here = os.path.dirname(__file__)
sol_path = os.path.join(here, '..', 'contracts', 'StudentManager.sol')
with open(r'C:\Users\ADMIN\Documents\student-manager-blockchain\contracts\StudentManager.sol', 'r', encoding='utf-8') as f:
    source = f.read()


# Install solc version 0.8.19 (Compile bằng solcx 0.8.19t)
print('Installing solc 0.8.19 (may download) ...')
install_solc('0.8.19')

compiled = compile_standard({
    "language": "Solidity",
    "sources": {"StudentManager.sol": {"content": source}},
    "settings": {
        "outputSelection": {
            "*": {
                "*": ["abi", "metadata", "evm.bytecode", "evm.sourceMap"]
            }
        }
    }
}, solc_version='0.8.19')

abi = compiled['contracts']['StudentManager.sol']['StudentManager']['abi']
bytecode = compiled['contracts']['StudentManager.sol']['StudentManager']['evm']['bytecode']['object']

# Sử dụng tài khoản Ganache đầu tiên (đã mở khóa) để triển khai (deploy)
account = w3.eth.accounts[0]
w3.eth.default_account = account
StudentManager = w3.eth.contract(abi=abi, bytecode=bytecode)
print('Deploying contract from account:', account)
tx_hash = StudentManager.constructor().transact()
receipt = w3.eth.wait_for_transaction_receipt(tx_hash)
address = receipt.contractAddress
print('Contract deployed at', address)

out = {'address': address, 'abi': abi}
with open(os.path.join(here, 'deployed.json'), 'w') as f:
    json.dump(out, f, indent=2)
print('deployed.json written. You can now run python app.py')
