# Student Manager Blockchain (Flask + Ganache)

This project is a simple demo for storing student grades on a local blockchain (Ganache) using a Flask backend.
It includes:
- Solidity contract `contracts/StudentManager.sol`
- Deployment script `flask_server/deploy.py` (uses py-solc-x + web3)
- Flask server `flask_server/app.py` that serves the frontend and provides API endpoints
- Simple frontend `frontend/index.html` using Bootstrap

## Prerequisites
- Python 3.8+
- Ganache running (GUI or CLI) on `http://127.0.0.1:7545` (default)
- Install Python dependencies:
  ```bash
  pip install web3 py-solc-x flask
  ```

## Steps to run (quick)
1. Start Ganache (default port 7545). Leave it running.
2. Compile & deploy the smart contract (this will create `flask_server/deployed.json`):
   ```bash
   cd flask_server
   python deploy.py
   ```
   The script will use the first Ganache account (unlocked by Ganache) to deploy.
3. Run Flask server:
   ```bash
   python app.py
   ```
4. Open your browser at `http://127.0.0.1:5000` and use the form to save grades and search them.

## Notes
- The deploy script uses `solcx` to compile; it will download the specified solc version if needed.
- The Flask server relies on Ganache unlocked accounts to send transactions without manual signing.
- If you prefer to sign transactions locally, you can modify `app.py` to sign with a private key.
